import UIKit

var greeting = "Hello, playground"

var a=0
var b=10

while (b-2)
