//
//  Categories.swift
//  News_App_iOS
//
//  Created by student on 5/1/22.
//

import Foundation

class Collection {
  var category : String
  var name : String
  
  init(category: String, name: String) {
    self.category = category
    self.name = name
  }
}
