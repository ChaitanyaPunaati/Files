//
//  CategoriesViewController.swift
//  News_App_iOS
//
//  Created by student on 4/6/22.
//

import UIKit

class CategoriesViewController: UIViewController, UISearchResultsUpdating, UISearchBarDelegate {
    func updateSearchResults(for searchController: UISearchController) {
        let searchBar = searchController.searchBar
        let scope = searchBar.scopeButtonTitles![searchBar.selectedScopeButtonIndex]
        filterContentForSearchText(searchController.searchBar.text!,scope: scope)
    }
    func searchBar(_ searchBar: UISearchBar, selectedScopeButtonIndexDidChange selectedScope: Int) {
      filterContentForSearchText(searchBar.text!, scope: searchBar.scopeButtonTitles![selectedScope])
    }
    

    @IBOutlet weak var headlines: UITableView!
    @IBAction func searchButton(_ sender: Any) {
    }
    
    var Categories = [Collection]()
    var filteredCandies = [Collection]()
    let searchController = UISearchController(searchResultsController: nil)
    
    @IBOutlet weak var categoryName: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        Categories = [
            Collection(category:"Sport", name:"Chocolate Bar"),
            Collection(category:"Sport", name:"Chocolate Chip"),
            Collection(category:"Sport", name:"Dark Chocolate"),
            Collection(category:"Politics", name:"Lollipop"),
            Collection(category:"Politics", name:"Candy Cane"),
            Collection(category:"Politics", name:"Jaw Breaker"),
            Collection(category:"Weather", name:"Caramel"),
            Collection(category:"Weather", name:"Sour Chew"),
            Collection(category:"Weather", name:"Gummi Bear")
        ]
        setupSearchController()
    }
    
    func setupSearchController () {
        searchController.searchResultsUpdater = self
        searchController.searchBar.scopeButtonTitles = ["All","Sport","Politics","Weather"]
        searchController.searchBar.delegate = self
        if #available(iOS 11, *) {
            self.navigationItem.searchController = searchController
            self.navigationItem.searchController?.isActive = true
            self.navigationItem.hidesSearchBarWhenScrolling = false
        } else {
            tableView.tableHeaderView = searchController.searchBar
        }
    }
    
    func filterContentForSearchText(_ searchText: String, scope: String = "All") {
          filteredCandies = Categories.filter { candy in
              if !(candy.category == scope) && scope != "All" {
                  return false
              }
              
              return candy.name.lowercased().contains(searchText.lowercased()) || searchText == ""
          }
          
          tableView.reloadData()
    }
   
    override func didReceiveMemoryWarning() {
      super.didReceiveMemoryWarning()
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
      return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
      if searchController.isActive {
        return filteredCandies.count
      }
      return Categories.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
      let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
      
      let c: Collection
      if searchController.isActive {
        c = filteredCandies[(indexPath as NSIndexPath).row]
      } else {
        c = Categories[(indexPath as NSIndexPath).row]
      }
      cell.textLabel!.text = c.name
      cell.detailTextLabel!.text = c.category
      return cell
    }
    
    


}
