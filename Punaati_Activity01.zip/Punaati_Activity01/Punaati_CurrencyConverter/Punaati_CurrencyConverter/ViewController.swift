//
//  ViewController.swift
//  Punaati_CurrencyConverter
//
//  Created by Punaati,Chaitanya on 2/24/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nameField: UITextField!
    
    @IBOutlet weak var inrTextField: UITextField!
    
    
    @IBOutlet weak var usdTextField: UITextField!
    
    @IBOutlet weak var displayLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func convertCurrencyButton(_ sender: UIButton) {
        var name = nameField.text!
        var inr = Double(inrTextField.text!)!
        var usd = Double(usdTextField.text!)!
        
        var inrConvert = round((inr/(74.64))*100)/100
        var usdConvert = round((usd*(74.64))*100)/100
        
        displayLabel.text = "Hello \(name),\rAmount Rs.\(inr) in USD is $\(inrConvert)\rAmount $\(usd) in INR is Rs.\(usdConvert)"
    }
}

