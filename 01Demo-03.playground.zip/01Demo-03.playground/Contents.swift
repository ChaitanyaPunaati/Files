import UIKit

var greeting = "Hello, playground"

print("Hi",10,10.25) //comma separated gives a space in the output

// String interpolation
var name = "Chaitu"
var grade = 89.92
print("Hello, \(name)")

print("Hello, \(name)! your grade is \(grade)")

var proLan = "Swift"
print("I Like the \(proLan) programming language")

var age = 23
print("you are \(age) years old and in another \(age) years you will be \(age*2) years old")

// \r carriage return
print("Hello All, \rWelcome to Swift programming language")

print("""
Hello
World!
""") // to print the bulk lines of message in the same way you write

print("The list of numbers are")
print(1,2,3,4,5,6)
print("The new pattern is", terminator: "-")
print(1,2,3,4,5,6, separator:"-")

let welcomemessage : String = "Hello"
print(welcomemessage,"All")


// Worksheet 2 on variables and constants

var mobilebrand = "Apple" // declaring a variable
mobilebrand = "samsung" // changing variable value
print(mobilebrand)

let pi = 3.14 // declaring a constant
print(pi)

var course : String = "IOS"
print(course)

var age1 : Int = 23
print("You are \(age) years old and you are doing \(course) course")

var course1 = "IOS"
var course2 : String = "JAVA"
print(course1,course2) // printing course1 and course2
print(course1,course2, separator:" & ") // printing course1 and course2 with separator &
print(course1,"-",course2)
print(course1,
course2)
print("""
\(course1),
\(course2)
""")

print(10,20,30)
print(12.5,15.5)


// Worksheet 03 on Tuples

var httpError = (errorcode : 404, errormessage : "Page not found")
print(httpError)
print(httpError.errorcode)
print(httpError.errormessage)
print(httpError.errorcode,httpError.errormessage)
print(httpError.errorcode,httpError.errormessage,separator:"-")
print(httpError.errorcode, terminator:":")
print(httpError.errormessage)

var stuName = ("john", "Smith")
var fName = stuName.0
var lName = stuName.1
print(fName, terminator: ",")
print(lName)

var origin = (x : 0 , y : 0)
var point = origin
print(point)
print(origin)
print(point.0,origin.0)

let city = (name : "Maryville" , population : 11,000)
let (cityName ,cityPopulation ) = (city.0 , city.1)
print(cityName)
print(cityPopulation)
print(city)
